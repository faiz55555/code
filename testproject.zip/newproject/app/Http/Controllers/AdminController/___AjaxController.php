<?php

namespace App\Http\Controllers\AdminController;

use App\Blog;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect,Response;

class AjaxController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //$data['users'] = Blog::orderBy('id','desc')->paginate(8);
        //return view('ajax-crud',$data);
        $data = Blog::get();
        return view('ajax-crud')->with(compact('data'));
       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       dd($request); 
        $userId = $request->user_id;
        $blog   =   Blog::updateOrCreate(['id' => $userId],
                    ['name' => $request->name, 'description' => $request->description]);
    
        return Response::json($blog);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $where = array('id' => $id);
        $data  = Blog::where($where)->first();
        return Response::json($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = Blog::where('id',$id)->delete();
   
        return Response::json($data);
    }
}
